# Tom and Jerry: Mouse Maze → Android

Juego J2ME (GlobalFun, MIDP-2.0, 128x128) empaquetado para Android usando el
emulador open source **J2ME-Loader**, que se descarga y compila en GitHub Actions.

## Compilar
1. Crea un repo en GitHub y sube todo el contenido de este ZIP.
2. Pestaña **Actions → Build Android APK → Run workflow** (o hace push a `main`).
3. Al terminar (~5-10 min) descarga el artefacto **TomAndJerry-APK** → trae el `.apk`.

## Primer uso
1. Instala el APK en el móvil.
2. En la app pulsa **+** → selecciona `tom_and_jerry_mouse_maze.jar`
   (el .jar viene en el artefacto; cópialo al móvil).
3. Toca el juego → **Configurar** y ajusta:
   - **Pantalla**: 128x128, escalado "Ajustar a pantalla" (activa mantener proporción).
   - **Teclado virtual**: activar → diseño "Teléfono" o "Cursor + OK";
     activa "Cruceta" para mover y asigna Fire/OK a los botones A, y
     las teclas blandas (izq/der) a las esquinas.
   - Ajusta tamaño y transparencia de botones arrastrándolos (modo edición).
4. Pulsa Iniciar.

## Controles del juego (J2ME)
- Cruceta / 2-4-6-8: mover
- OK / 5: acción
- Teclas blandas: menú / atrás
